Instructions To Build Package
===================

- Open the package project (file ending with '.Rproj') by double clicking it
- Install any missing dependancies for the package by running:
```r
source('./extras/packageDeps.R')
```
- Build the package by clicking the R studio 'Install and Restart' button in the build tab (top right)


