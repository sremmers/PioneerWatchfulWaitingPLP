

# add error tests

# train and save model, add validation dummy then test document 

#

